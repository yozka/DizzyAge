/////////////////////////////////////////////////////////////////////////////////
#ifndef __A9CODEC_OGG__
#define __A9CODEC_OGG__
#include "a9codec.h"
#include <vorbis/codec.h>
#include <vorbis/vorbisfile.h>

/////////////////////////////////////////////////////////////////////////////////
class a9Codec_ogg : public a9Codec
{
public:
					a9Codec_ogg();
virtual				~a9Codec_ogg();
static	int			Init();
static	int			Done();	

virtual	int			Open( char* name );
virtual	int			BeginRender( int pos, int loop );
virtual int			Render( byte* buffer, int size );
virtual	int			EndRender();
virtual	int			Close();
virtual int			GetLength();

private:
		OggVorbis_File	m_oggfile;
		byte*			m_pcmbuf;
		int				m_pcmpos;
		int				m_pcmcnt;
};

#endif
/////////////////////////////////////////////////////////////////////////////////
