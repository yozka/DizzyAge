#include "stdafx.h"
#include "a9file.h"

/////////////////////////////////////////////////////////////////////////////////
// FILE
/////////////////////////////////////////////////////////////////////////////////
int a9FileMEM::Open( char* name, char* mode )
{
	if(m_open) return -1;
	if(name==NULL) return -1;
	if(*((dword*)(name))!=FILENAMEID) return -1;
	a9FileName* s = (a9FileName*)name;
	m_addr = (byte*)(s->m_addr);
	m_size = s->m_size;
	m_open = 1;
	m_pos = 0;
	return 0;
}

int a9FileMEM::Seek( int pos, int mode )
{
	if(!m_open) return -1;
	if(mode==0 && pos>=0 && pos<=m_size) { m_pos = pos; return 0; }
	else
	if(mode==1 && m_pos+pos>=0 && m_pos+pos<=m_size) { m_pos += pos; return 0; }
	else
	if(mode==2 && m_size-pos>=0 && m_size-pos<=m_size) { m_pos = m_size-pos; return 0; }
	else
	return -1;
}

int	a9FileMEM::Read( void* buffer, int size )
{
	if(!m_open) return 0;
	int s = size;
	if(m_pos+s>m_size) s=m_size-m_pos;
	memcpy(buffer,m_addr+m_pos,s);
	m_pos+=s;
	return s;
}
/*
char* FILEMEM_MKNAME( void* addr, int size );
{
	static a9FileName s;
	s.m_id = FILENAMEID;
	s.m_addr = addr;
	s.m_size = size;
	
#define FILEMEM_MAKENAME( buff, addr, size )	((char*)a9FileName( FILENAMEID, addr, size ))
}
*/
/////////////////////////////////////////////////////////////////////////////////
// callbacks
/////////////////////////////////////////////////////////////////////////////////
void* a9_fopen( char* filename, char* mode )
{
	if(filename==NULL) return NULL;
	a9File* file;

	if(filename[0]=='*')
	{
		a9FileName* s = (a9FileName*)filename;
		if(s->m_id==FILENAMEID)	
			file = new a9FileMEM();
		else
			return NULL;
	}
	else
	{
		file = new a9FileSTD();
	}

	int ret = file->Open( filename, mode );
	if(ret==-1) { delete(file); return NULL; }
	return file;
}

int	a9_fclose	( void* file )								{ return ((a9File*)file)->Close(); }
int	a9_fseek	( void* file, int pos, int mode )			{ return ((a9File*)file)->Seek( pos, mode ); }
int	a9_ftell	( void* file )								{ return ((a9File*)file)->Tell(); }
int	a9_feof		( void* file )								{ return ((a9File*)file)->Eof(); }
int	a9_fread	( void* buffer, int size, void* file )		{ return ((a9File*)file)->Read( buffer, size ); }

/////////////////////////////////////////////////////////////////////////////////
