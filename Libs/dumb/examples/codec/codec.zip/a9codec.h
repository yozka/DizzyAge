/////////////////////////////////////////////////////////////////////////////////
#ifndef __A9CODEC__
#define __A9CODEC__
#include "a9def.h"

#define A9CODEC_CLOSE		(0)
#define A9CODEC_OPEN		(1)
#define A9CODEC_RENDER		(2)

/////////////////////////////////////////////////////////////////////////////////
// Obs: all positons and sizes are in samples unless otherwise noted
/////////////////////////////////////////////////////////////////////////////////
struct a9InfoSrc
{
	int		m_depth;
	int		m_signed;
	int		m_channels;
	int		m_frequency;
};

/////////////////////////////////////////////////////////////////////////////////
class a9Codec
{
public:
					a9Codec();
virtual				~a9Codec()								{};
virtual	int			Open( char* name )						{ return A9_FAIL; }
virtual	int			BeginRender( int pos, int loop )		{ return A9_FAIL; }
virtual int			Render( byte* buffer, int size )		{ return 0; }
virtual	int			EndRender()								{ return A9_FAIL; }
virtual	int			Close()									{ return A9_FAIL; }

virtual int			GetLength()								{ return 0; }
inline	int			GetSampleSize()							{ return m_infosrc.m_channels*(m_infosrc.m_depth>>3); } // return sample size in bytes

		a9InfoSrc	m_infosrc;
		void*		m_file;
		int			m_loop;
		int			m_status;
		int			m_eos;
};

#endif
/////////////////////////////////////////////////////////////////////////////////
