/////////////////////////////////////////////////////////////////////////////////
#ifndef __A9CODEC_DUMB__
#define __A9CODEC_DUMB__
#include "a9codec.h"
#include "dumb.h"

/////////////////////////////////////////////////////////////////////////////////
class a9Codec_dumb : public a9Codec
{
public:
					a9Codec_dumb();
virtual				~a9Codec_dumb();
static	int			Init();
static	int			Done();	

virtual	int			Open( char* name );
virtual	int			BeginRender( int pos, int loop );
virtual int			Render( byte* buffer, int size );
virtual	int			EndRender();
virtual	int			Close();
virtual int			GetLength();

private:
		DUH*				m_duh;
		DUH_SIGRENDERER*	m_duhsr;
};

#endif
/////////////////////////////////////////////////////////////////////////////////
