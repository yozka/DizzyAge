#include "stdafx.h"
#include "a9file.h"
#include "a9Codec_ym.h"

/////////////////////////////////////////////////////////////////////////////////

/*
// callbacks used just when open duh and load it in own memory
void*	dumb_open	(const char *filename)			{ return a9_fopen((char*)filename,"rb"); }
int		dumb_skip	(void *f, long n)				{ return a9_fseek(f,n,1); }
int		dumb_getc	(void *f)						{ int c=0; if(1!=a9_fread(&c,1,f)) return -1; else return c; }
long	dumb_getnc	(char *ptr, long n, void *f)	{ return a9_fread(ptr,n,f); }
void	dumb_close	(void *f)						{ a9_fclose(f); }

DUMBFILE_SYSTEM dumb_fs;
*/

/////////////////////////////////////////////////////////////////////////////////
a9Codec_ym::a9Codec_ym()
{
	m_ym		= NULL;
}

a9Codec_ym::~a9Codec_ym()
{
}

int a9Codec_ym::Init()
{
/*	atexit(&dumb_exit);
	//dumb_register_stdfiles();
	dumb_fs.open	= dumb_open;
	dumb_fs.skip	= dumb_skip;
	dumb_fs.getc	= dumb_getc;
	dumb_fs.getnc	= dumb_getnc;
	dumb_fs.close	= dumb_close;
	register_dumbfile_system(&dumb_fs);
	dumb_it_max_to_mix = 256;
*/	return A9_OK;
}

int a9Codec_ym::Done()
{
	//...
	return A9_OK;
}

int	a9Codec_ym::Open( char* name )
{
	if(m_status!=A9CODEC_CLOSE) return A9_FAIL;
	m_ym = ymMusicCreate(); if(!m_ym) return A9_FAIL;
	if(!ymMusicLoad(m_ym,name)) return A9_FAIL;
	
	m_infosrc.m_depth		= 16;
	m_infosrc.m_signed		= 1;
	m_infosrc.m_channels	= 1;
	m_infosrc.m_frequency	= 44100;

	m_status = A9CODEC_OPEN;
	return A9_OK;
}

int	a9Codec_ym::BeginRender( int pos, int loop )
{
	if(m_status!=A9CODEC_OPEN) return A9_FAIL;
	m_eos = 0;
	m_loop = loop;

	ymMusicSetLoopMode(m_ym,loop);
	ymMusicPlay(m_ym);

	m_status = A9CODEC_RENDER;
	return A9_OK;
}

int	a9Codec_ym::Render( byte* buffer, int size )
{
	if(m_status!=A9CODEC_RENDER) return A9_FAIL;
	int ret = ymMusicCompute(m_ym,(ymsample*)buffer,size);
	return size;
}

int	a9Codec_ym::EndRender()
{
	if(m_status!=A9CODEC_RENDER) return A9_FAIL;
	ymMusicStop(m_ym);
	m_status = A9CODEC_OPEN;
	return A9_OK;
}

int	a9Codec_ym::Close()
{
	if(m_status!=A9CODEC_OPEN) return A9_FAIL;
	ymMusicDestroy(m_ym);
	m_status = A9CODEC_CLOSE;
	return A9_OK;
}

int	a9Codec_ym::GetLength()
{
	if(m_status!=A9CODEC_OPEN && m_status!=A9CODEC_RENDER) return 0;
//	int duhsize = duh_get_length(m_duh);
//	int samples	= (int) (((float)duhsize / DUMB_SEC) * m_infosrc.m_frequency);
//	return samples;
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////

