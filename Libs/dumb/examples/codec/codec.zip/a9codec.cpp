#include "stdafx.h"
#include "a9codec.h"

a9Codec::a9Codec()
{
	m_infosrc.m_depth		= 0;
	m_infosrc.m_signed		= 0;
	m_infosrc.m_channels	= 0;
	m_infosrc.m_frequency	= 0;

	m_file					= NULL; 
	m_loop					= 0;
	m_status				= A9CODEC_CLOSE; 
	m_eos					= 0;
}


/////////////////////////////////////////////////////////////////////////////////
