#include "stdafx.h"
#include "a9file.h"
#include "a9Codec_dumb.h"

/////////////////////////////////////////////////////////////////////////////////
#define DUMB_SEC 65536.0f

// callbacks used just when open duh and load it in own memory
void*	dumb_open	(const char *filename)			{ return a9_fopen((char*)filename,"rb"); }
int		dumb_skip	(void *f, long n)				{ return a9_fseek(f,n,1); }
int		dumb_getc	(void *f)						{ int c=0; if(1!=a9_fread(&c,1,f)) return -1; else return c; }
long	dumb_getnc	(char *ptr, long n, void *f)	{ return a9_fread(ptr,n,f); }
void	dumb_close	(void *f)						{ a9_fclose(f); }

DUMBFILE_SYSTEM dumb_fs;


/////////////////////////////////////////////////////////////////////////////////
a9Codec_dumb::a9Codec_dumb()
{
	m_duh		= NULL;
	m_duhsr		= NULL;
}

a9Codec_dumb::~a9Codec_dumb()
{
}

int a9Codec_dumb::Init()
{
	atexit(&dumb_exit);
	//dumb_register_stdfiles();
	dumb_fs.open	= dumb_open;
	dumb_fs.skip	= dumb_skip;
	dumb_fs.getc	= dumb_getc;
	dumb_fs.getnc	= dumb_getnc;
	dumb_fs.close	= dumb_close;
	register_dumbfile_system(&dumb_fs);
	dumb_it_max_to_mix = 256;
	return A9_OK;
}

int a9Codec_dumb::Done()
{
	//...
	return A9_OK;
}

int	a9Codec_dumb::Open( char* name )
{
	if(m_status!=A9CODEC_CLOSE) return A9_FAIL;
	// set user callbacks
	// load
	m_duh = load_duh(name);
	if(!m_duh) 
	{
		m_duh = dumb_load_it(name);
		if(!m_duh) 
		{
			m_duh = dumb_load_xm(name);
			if(!m_duh) 
			{
				m_duh = dumb_load_s3m(name);
				if(!m_duh) 
				{
					m_duh = dumb_load_mod(name);
					if(!m_duh) 
					{
						return A9_FAIL;
					}
				}
			}
		}
	}
	
	m_infosrc.m_depth		= 16;
	m_infosrc.m_signed		= 1;
	m_infosrc.m_channels	= 2;
	m_infosrc.m_frequency	= 44100;

	m_status = A9CODEC_OPEN;
	return A9_OK;
}

int	a9Codec_dumb::BeginRender( int pos, int loop )
{
	if(m_status!=A9CODEC_OPEN) return A9_FAIL;
	m_eos = 0;
	m_loop = loop;

	m_duhsr = duh_start_sigrenderer(m_duh, 0, 2, pos); // 0sig, 2channels, pos
	if(!m_duhsr) return A9_FAIL;

	// no loop
	if(!loop)
	{
		DUMB_IT_SIGRENDERER * itsr = duh_get_it_sigrenderer(m_duhsr);
		dumb_it_set_loop_callback(itsr,dumb_it_callback_terminate,NULL);
	}

	m_status = A9CODEC_RENDER;
	return A9_OK;
}

int	a9Codec_dumb::Render( byte* buffer, int size )
{
	if(m_status!=A9CODEC_RENDER) return A9_FAIL;
	float volume = 1.0f;
	float delta = DUMB_SEC / m_infosrc.m_frequency;
	int ret = duh_render(m_duhsr, m_infosrc.m_depth, !m_infosrc.m_signed, volume, delta, size, buffer);
	return ret;
}

int	a9Codec_dumb::EndRender()
{
	if(m_status!=A9CODEC_RENDER) return A9_FAIL;
	duh_end_sigrenderer(m_duhsr);
	m_status = A9CODEC_OPEN;
	return A9_OK;
}

int	a9Codec_dumb::Close()
{
	if(m_status!=A9CODEC_OPEN) return A9_FAIL;
	unload_duh(m_duh);
	m_status = A9CODEC_CLOSE;
	return A9_OK;
}

int	a9Codec_dumb::GetLength()
{
	if(m_status!=A9CODEC_OPEN && m_status!=A9CODEC_RENDER) return 0;
	int duhsize = duh_get_length(m_duh);
	int samples	= (int) (((float)duhsize / DUMB_SEC) * m_infosrc.m_frequency);
	return samples;
}

/////////////////////////////////////////////////////////////////////////////////

