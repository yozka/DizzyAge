/////////////////////////////////////////////////////////////////////////////////
#ifndef __A9FILE__
#define __A9FILE__
#include "a9def.h"

/////////////////////////////////////////////////////////////////////////////////
// FILE
/////////////////////////////////////////////////////////////////////////////////
struct a9FileName
{
	a9FileName( dword id, void* addr, int size )	{ m_id=id; m_addr=addr; m_size=size; }
	dword	m_id;
	void*	m_addr;
	int		m_size;
	inline	operator char*()						{ return (char*)(this); }

};

class a9File
{
public:
		a9File()										{};
virtual	~a9File()										{};
virtual	int			Open( char* name, char* mode )		{ return -1; }
virtual	int			Close()								{ return 0; }
virtual	int 		Seek( int pos, int mode )			{ return -1; }
virtual	int			Tell()								{ return 0; }
virtual int			Eof()								{ return 0; }
virtual	int			Read( void* buffer, int size )		{ return 0; }
};

class a9FileSTD : public a9File
{
public:
		a9FileSTD()										{ m_file=NULL; }
virtual	~a9FileSTD()									{};
virtual	int			Open( char* name, char* mode )		{ m_file=fopen( name, mode ); return m_file?0:-1; }
virtual	int 		Close()								{ return fclose(m_file); }
virtual	int 		Seek( int pos, int mode )			{ return fseek(m_file,pos,mode); };
virtual	int			Tell()								{ return ftell(m_file); }
virtual int			Eof()								{ return feof(m_file); }
virtual	int			Read( void* buffer, int size )		{ return fread(buffer, 1, size, m_file); }

protected:
		FILE*		m_file;
};

#define FILENAMEID								0x4d2a
#define FILEMEM_MAKENAME( addr, size )			a9FileName( FILENAMEID, addr, size )
/*
char* FILEMEM_MKNAME( void* addr, int size );
{
}
*/
class a9FileMEM : public a9File
{
public:
		a9FileMEM()										{ m_addr=NULL; m_size=0; m_open=0; m_pos=0; }
virtual	~a9FileMEM()									{};
virtual	int			Open( char* name, char* mode );
virtual	int			Close()								{ if(!m_open) return -1; m_open=0; return 0; }
virtual	int 		Seek( int pos, int mode );
virtual	int			Tell()								{ if(m_open) return m_pos; else return -1; }
virtual int			Eof()								{ return m_pos==m_size; }
virtual	int			Read( void* buffer, int size );

protected:
		byte*		m_addr;		// address
		int			m_size;		// size
		int			m_open;		// 0=closed, 1=read, 2=write
		int			m_pos;		// cursor
};

/////////////////////////////////////////////////////////////////////////////////
// callbacks
/////////////////////////////////////////////////////////////////////////////////
void*	a9_fopen	( char* filename, char* mode );
int		a9_fclose	( void* file );
int		a9_fseek	( void* file, int pos, int mode );
int		a9_ftell	( void* file );
int		a9_feof		( void* file );
int		a9_fread	( void* buffer, int size, void* file );

#endif
/////////////////////////////////////////////////////////////////////////////////