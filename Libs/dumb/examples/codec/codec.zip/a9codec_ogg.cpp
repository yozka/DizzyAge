#include "stdafx.h"
#include "a9file.h"
#include "a9codec_ogg.h"

/////////////////////////////////////////////////////////////////////////////////
#define PCMSIZE 4096	// pcm read buffer size

size_t ogg_read		(void *ptr, size_t size, size_t nmemb, void *datasource) { return a9_fread(ptr, size*nmemb, datasource); }
int    ogg_seek		(void *datasource, ogg_int64_t offset, int whence) { return a9_fseek(datasource, (int)offset, whence); }
int    ogg_close	(void *datasource) { return a9_fclose(datasource); }
long   ogg_tell		(void *datasource) { return a9_ftell(datasource); }


/////////////////////////////////////////////////////////////////////////////////
a9Codec_ogg::a9Codec_ogg()
{
	m_pcmbuf = NULL;
	m_pcmpos = 0;
	m_pcmcnt = 0;
}

a9Codec_ogg::~a9Codec_ogg()
{
}

int a9Codec_ogg::Init()
{
	return A9_OK;
}

int a9Codec_ogg::Done()
{
	return A9_OK;
}

int	a9Codec_ogg::Open( char* name )
{
	if(m_status!=A9CODEC_CLOSE) return A9_FAIL;

	// set user callbacks
	ov_callbacks mycallbacks = { ogg_read, ogg_seek, ogg_close, ogg_tell };
	m_file = a9_fopen( name, "rb" ); 
	if(!m_file) return A9_FAIL;

	if(ov_open_callbacks(m_file, &m_oggfile, NULL, 0, mycallbacks) < 0) { a9_fclose(m_file); return A9_UNSUPORTED; }

	m_pcmbuf = (byte*)malloc(PCMSIZE);
	m_pcmpos = 0;
	m_pcmcnt = 0;

    char** comment			= ov_comment(&m_oggfile,-1)->user_comments;
    vorbis_info* vi			= ov_info(&m_oggfile,-1);
	m_infosrc.m_signed		= 1;
	m_infosrc.m_depth		= 16;
	m_infosrc.m_channels	= vi->channels;
	m_infosrc.m_frequency	= vi->rate;

	m_status = A9CODEC_OPEN;
	return A9_OK;
}

int	a9Codec_ogg::BeginRender( int pos, int loop )
{
	if(m_status!=A9CODEC_OPEN) return A9_FAIL;
	m_eos = 0;
	m_loop = loop;
	m_pcmpos = 0;
	m_pcmcnt = 0;
	int ret = ov_pcm_seek( &m_oggfile, pos ); // reset for looping
	if(ret!=0) return A9_FAIL; 

	m_status = A9CODEC_RENDER;
	return A9_OK;
}

int	a9Codec_ogg::Render( byte* buffer, int size )
{
	if(m_status!=A9CODEC_RENDER) return A9_FAIL;
	int pos=0; // current position in buffer (in bytes)
	int memsize = size * GetSampleSize(); // size of buffer (in bytes)

	// leftovers
	if(m_pcmpos>0)
	{
		memcpy(buffer, m_pcmbuf+m_pcmpos, m_pcmcnt);
		pos += m_pcmcnt;
	}

	while(1)
	{
		m_pcmpos = 0;
		int current_section;
		long ret=ov_read( &m_oggfile, (char*)m_pcmbuf, PCMSIZE, 0, m_infosrc.m_depth>>3, m_infosrc.m_signed, &current_section );
		if(ret==0) 
		{
			// @TODO user callback ?
			if(m_loop)
			{
				ret = ov_raw_seek( &m_oggfile, 0 ); // reset for looping
				if(ret==0) continue; 
				else ret =-1; // report error
			}
			else
			{
				m_eos = 1;
				return pos/GetSampleSize();
			}
		}
		if(ret<0) return A9_ERROR;

		// printf("p=%i r=%i\n",pos,ret);

		if(pos+ret>memsize) // too much, keep leftovers
		{
			m_pcmpos = memsize-pos;
			m_pcmcnt = ret - m_pcmpos;
			ret = memsize-pos;
			memcpy(buffer+pos, m_pcmbuf, ret);
			return size;
		}
		else
		{
			memcpy(buffer+pos, m_pcmbuf, ret);
			pos += ret;
			if(pos==memsize) return size; // fix!
		}
	}
}

int	a9Codec_ogg::EndRender()
{
	if(m_status!=A9CODEC_RENDER) return A9_FAIL;
	m_pcmpos = 0;
	m_pcmcnt = 0;
	m_status = A9CODEC_OPEN;
	return A9_OK;
}

int	a9Codec_ogg::Close()
{
	if(m_status!=A9CODEC_OPEN) return A9_FAIL;
	if(m_pcmbuf) free(m_pcmbuf);
	ov_clear(&m_oggfile);
	if(m_file) a9_fclose(m_file);
	m_status = A9CODEC_CLOSE;
	return A9_OK;
}

int	a9Codec_ogg::GetLength()
{
	if(m_status!=A9CODEC_OPEN && m_status!=A9CODEC_RENDER) return 0;
	int samples = (int)ov_pcm_total(&m_oggfile,-1);
	return samples;
}
/////////////////////////////////////////////////////////////////////////////////

