/////////////////////////////////////////////////////////////////////////////////
#ifndef __A9DEF__
#define __A9DEF__

typedef unsigned int		dword;
typedef unsigned short int	word;
typedef unsigned char		byte;

#define A9_OK				0
#define A9_FAIL				-1
#define A9_ERROR			-1
#define A9_UNSUPORTED		-2
#define A9_EOF				-1

#endif