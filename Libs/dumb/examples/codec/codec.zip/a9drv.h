/////////////////////////////////////////////////////////////////////////////////
#ifndef __A9DRV__
#define __A9DRV__
#include "a9def.h"
typedef dword				DWORD_PTR;
#include "Dsound.h"

/////////////////////////////////////////////////////////////////////////////////
class a9Drv
{
public:
					a9Drv();
virtual				~a9Drv();
virtual	int			Init( HWND hwnd );
virtual	void		Done();
virtual	int			Get( int idx );
virtual	void		Set( int idx, int val );

		HWND						m_hwnd;
		LPDIRECTSOUND				m_ds;
		LPDIRECTSOUNDBUFFER			m_dsbuffer;
		LPDIRECTSOUND3DLISTENER		m_dslistener;
		DS3DLISTENER				m_dslistenerprops;

};

#endif
/////////////////////////////////////////////////////////////////////////////////