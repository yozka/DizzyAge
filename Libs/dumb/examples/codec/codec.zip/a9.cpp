/////////////////////////////////////////////////////////////////////////////////
// a9.cpp : Defines the entry point for the console application.

#include "stdafx.h"
#include "conio.h"
#include "a9file.h"
#include "a9codec_ogg.h"
#include "a9codec_dumb.h"
#include "a9codec_ym.h"
#include "SoundServer.h"

#include "a9drv.h"
#include "a9buffer.h"

/////////////////////////////////////////////////////////////////////////////////
// drivers and codecs
/////////////////////////////////////////////////////////////////////////////////
static	CSoundServer soundServer;
int g_servermuststop;

//a9Codec_ogg g_codec;
a9Codec_ym g_codec;

/////////////////////////////////////////////////////////////////////////////////
// OGG
/////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vorbis/codec.h>
#include <vorbis/vorbisfile.h>

#ifdef _WIN32 /* We need the following two to set stdin/stdout to binary */
#include <io.h>
#include <fcntl.h>
#endif

/////////////////////////////////////////////////////////////////////////////////
// EXPORT
/////////////////////////////////////////////////////////////////////////////////
void WavWriteHeader(FILE* ff)
{
	int data_written = 0;
	long l;
	const int fmt_size = 8 + 16;
	const int data_size = 8 + data_written;
	const int file_size = fmt_size + data_size;
	int bps = 44100 * 2 * 16 / 8;
	int align = 2*16/8;
	fwrite("RIFF",1,4,ff);
	fwrite(&file_size,1,4,ff);
	fwrite("WAVE",1,4,ff);
	fwrite("fmt ",1,4,ff);
	l=16;	fwrite(&l,1,4,ff);
	l=1;	fwrite(&l,1,2,ff);
	l=2;	fwrite(&l,1,2,ff);
	l=44100;fwrite(&l,1,4,ff);
	l=bps;	fwrite(&l,1,4,ff);
	l=align;fwrite(&l,1,2,ff);
	l=16;	fwrite(&l,1,2,ff);
	fwrite("data",1,4,ff);
	l=0;	fwrite(&l,1,4,ff);
}

void ExportTest( char* filename, char* target )
{
	printf("exporting...\n");
	int data_written = 0;
	FILE* fd=fopen(target,"wb");
	WavWriteHeader(fd);

	g_codec.Open(filename);
	g_codec.BeginRender(0,0);

	int outsize = 1000000;
	byte* outbuf = (byte*)malloc(outsize);

	while(1)
	{
		int samples = outsize/g_codec.GetSampleSize();
		int ret = g_codec.Render(outbuf,samples);
		if(ret<=0) break; // error
		fwrite(outbuf,1,ret*g_codec.GetSampleSize(),fd);
		data_written += ret*g_codec.GetSampleSize();
		if(ret<samples) break; // end
	}

	g_codec.EndRender();
	g_codec.Close();

	// repair header
	const int fmt_size = 8 + 16;
	const int data_size = 8 + data_written;
	const int file_size = fmt_size + data_size;
	fseek(fd, 4, SEEK_SET);
	fwrite(&file_size,1,4,fd);
	fseek(fd, 12 + fmt_size + 4, SEEK_SET);
	fwrite(&data_written,1,4,fd);
	fclose(fd);
}


/////////////////////////////////////////////////////////////////////////////////
// PLAY
/////////////////////////////////////////////////////////////////////////////////
static void soundServerCallback( void* buffer,long size )
{
	if(g_codec.m_status!=A9CODEC_RENDER) { g_servermuststop = 1; return; }
	int samplesize = g_codec.GetSampleSize();
	int samples = size / samplesize;

	if( !g_codec.m_eos )
	{
		int ret =g_codec.Render((byte*)buffer,samples);
		if(ret<=0) // error
		{
			memset((byte*)buffer, 0, size-ret*samplesize ); // clear
			g_servermuststop = 1;
		}
		else
		if(ret<samples) 
		{
			memset((byte*)buffer+ret, 0, size-ret*samplesize); // clear
			printf("last\n");
		}
	}
	else
		g_servermuststop = 1;
}

void PlayTest( char* filename )
{
	printf("playing...\n");
	g_codec.Open(filename);
	printf("length = %i\n", g_codec.GetLength());
	g_codec.BeginRender(0,1);

	g_servermuststop = 0;
	if(soundServer.open(soundServerCallback,2000))
	{
		while(1)
		{
			if(g_servermuststop) break;
			if(_kbhit())
			{
				char ch = _getch();
				if(ch==27) break;
			}
			Sleep(20);
		}
	}

	g_codec.EndRender();
	g_codec.Close();
}


/////////////////////////////////////////////////////////////////////////////////
// MAIN
/////////////////////////////////////////////////////////////////////////////////
int main(int argc, char* argv[])
{
	a9Codec_dumb::Init();
/*	char* buffer = (char*)malloc(1000); buffer[0]=0;
	char* dest = (char*)malloc(1000); dest[0]=0;
	void* f = a9_fopen("test.txt","rb");
	a9_fread(buffer,400,f);
	a9_fclose(f);
	void* g = a9_fopen( FILEMEM_MAKENAME( buffer, 400 ), "rb" );
	a9_fread(dest,400,g);
	a9_fclose(g);
	dest[400]=0;

	printf(dest);
	getch();
*/

/*	// load ogg in mem
	void* fo = a9_fopen("test.ogg","rb");
	a9_fseek(fo,0,2);
	int buffersize = a9_ftell(fo);
	a9_fseek(fo,0,0);
	void* buffer = malloc(buffersize);
	a9_fread(buffer,buffersize,fo);
	a9_fclose(fo);

*/

	//PlayTest( "test.ogg" );
	//ExportTest( "test.ogg", "testexp.wav" );
	//PlayTest( FILEMEM_MAKENAME( buffer, buffersize ) );
	//ExportTest( FILEMEM_MAKENAME( buffer, buffersize ), "testy.wav" );
	PlayTest( "test.xm" );
	//ExportTest( "test.xm", "testexp.wav" );
	//PlayTest( "test.ym" ); // use mono in server

	
//	free(buffer);
	fprintf(stderr,"Done.\n");
	return 0;
}

