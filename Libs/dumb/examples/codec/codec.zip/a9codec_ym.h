/////////////////////////////////////////////////////////////////////////////////
#ifndef __A9CODEC_YM__
#define __A9CODEC_YM__
#include "a9codec.h"
#include "StSoundLibrary.h"

/////////////////////////////////////////////////////////////////////////////////
class a9Codec_ym : public a9Codec
{
public:
					a9Codec_ym();
virtual				~a9Codec_ym();
static	int			Init();
static	int			Done();	

virtual	int			Open( char* name );
virtual	int			BeginRender( int pos, int loop );
virtual int			Render( byte* buffer, int size );
virtual	int			EndRender();
virtual	int			Close();
virtual int			GetLength();

private:
		YMMUSIC*	m_ym;
};

#endif
/////////////////////////////////////////////////////////////////////////////////
